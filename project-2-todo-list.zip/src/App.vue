<template>
  <v-app id="app">
    <Panel />
    <Table />
    <TaskCard id="newTask" style="display: none" taskType="Add Task" />
    <TaskCard id="editTask" style="display: none" taskType="Edit Task" />
  </v-app>
</template>

<script>
import Panel from "./components/Panel.vue";
import Table from "./components/Table.vue";
import TaskCard from "./components/TaskCard.vue";

export default {
  name: "App",
  components: {
    Panel,
    Table,
    TaskCard,
  },
};
</script>

<style scoped>
#editTask,
#newTask {
  position: absolute;
  height: 100%;
  width: 100%;
  margin-top: 8%;
  z-index: 3;
}
</style>
