<template>
  <v-data-table
    :headers="headers"
    :items="tasks"
    z-index="1"
    :hide-default-footer="true"
    no-data-text=""
  >
    <template v-slot:[`item.status`]="{ item }">
      <v-simple-checkbox v-model="item.status"></v-simple-checkbox>
    </template>

    <!-- entry fills in item.action with the following -->
    <template v-slot:[`item.action`]="{ item }">
      <v-row justify="center">
        <!-- only show update button if incomplete -->
        <v-btn v-if="!item.status" color="primary" @click="editTask(item)">
          <v-icon small class="mr-2"> mdi-square-edit-outline </v-icon>Update
        </v-btn>
      </v-row>
      <v-row justify="center">
        <v-btn color="error" @click="deleteItem(item)">
          <v-icon small class="mr-2"> mdi-close-circle </v-icon>Delete
        </v-btn>
      </v-row>
    </template>
  </v-data-table>
</template>

<script>
export default {
  name: "Table",
  mounted() {
    // listen to Task when user tries to update or add a new task
    this.$root.$on(
      "submit-new-change",
      (taskType, title, description, deadline, priority) => {
        // if new task
        if (taskType === "Add Task") {
          document.getElementById("newTask").style.display = "none";

          this.tasks.push({
            title: title,
            description: description,
            deadline: deadline,
            priority: priority,
            status: false,
            action: "",
          });
          this.$toastr.s("Task Added Successfully!");
        }
        // if old task, update the possibly edited fields
        else if (taskType === "Edit Task") {
          this.tasks[this.taskIndex].description = description;
          this.tasks[this.taskIndex].deadline = deadline;
          this.tasks[this.taskIndex].priority = priority;
          this.$toastr.s("Task Updated Successfully!");

          document.getElementById("editTask").style.display = "none";
        }
      }
    );
    // iterates through tasks to check for duplicate title (only emits when there's a duplicate)
    this.$root.$on("check-distinct-title", (title) => {
      // check the title is distinct
      for (let task of this.tasks) {
        if (task.title === title) {
          this.$root.$emit("non-distinct-title", task.title);
        }
      }
    });
  },
  data() {
    return {
      // tracks index of tasks when request to edit or delete
      taskIndex: -1,
      headers: [
        {
          text: "Title",
          value: "title",
          align: "center",
        },
        { text: "Description", value: "description", align: "center" },
        { text: "Deadline", value: "deadline", align: "center" },
        { text: "Priority", value: "priority", align: "center" },
        { text: "Is Complete", value: "status", align: "center" },
        { text: "Action", value: "action", align: "center" },
      ],
      tasks: [],
    };
  },
  methods: {
    editTask(item) {
      // communicate description, deadline, priority from table entry to form
      console.log("edit task");
      this.$root.$emit(
        "edit-table-entry",
        item.title,
        item.description,
        item.deadline,
        item.priority
      );
      // remember what the index of the item we are attempting to edit is
      this.taskIndex = this.tasks.indexOf(item);
      document.getElementById("editTask").style.display = "";
    },
    deleteItem(item) {
      this.tasks.splice(this.tasks.indexOf(item), 1);
      this.$toastr.s("Task Deleted Successfully!");
    },
  },
};
</script>
