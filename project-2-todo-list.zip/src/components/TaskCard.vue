<template>
  <v-row justify="center">
    <v-col cols="16" sm="3" md="3" lg="3">
      <v-overlay :dark="false">
        <v-form ref="form" id="form">
          <v-card>
            <v-toolbar dark color="primary" center>
              <v-icon v-if="taskType == 'Add Task'" med>add_circle</v-icon>
              <v-icon v-if="taskType == 'Edit Task'" med
                >mdi-square-edit-outline</v-icon
              >
              <b>{{ taskType }}</b>
            </v-toolbar>
            <v-card-text>
              <!-- title input -->
              <v-text-field
                v-if="taskType == 'Add Task'"
                v-model="title"
                placeholder="Title"
                :rules="[rules.titleReq, rules.distinctReq]"
                id="title"
                outlined
                required
              ></v-text-field>
              <!-- description input -->
              <v-text-field
                v-model="description"
                placeholder="Description"
                :rules="[rules.descReq]"
                outlined
                required
                >hi</v-text-field
              >
              <!-- deadline -->
              <v-menu
                ref="menu"
                v-model="menu"
                :close-on-content-click="false"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="formDeadline"
                    label="Date"
                    append-icon="mdi-calendar"
                    v-bind="attrs"
                    @blur="date = parseDate(formDeadline)"
                    v-on="on"
                    outlined
                    readonly
                  ></v-text-field>
                </template>
                <v-date-picker v-model="date" no-title @input="menu1 = false">
                  <v-spacer></v-spacer>
                  <v-btn text color="primary" @click="menu = false">
                    Cancel
                  </v-btn>
                  <v-btn text color="primary" @click="$refs.menu.save(date)">
                    OK
                  </v-btn>
                </v-date-picker>
              </v-menu>

              <!-- priority  -->
              <div>Priority</div>
              <v-radio-group
                class="justify-space-between"
                v-model="priority"
                row
                mandatory
              >
                <v-radio label="Low" value="low" selected></v-radio>
                <v-radio label="Med" value="med"></v-radio>
                <v-radio label="High" value="high"></v-radio>
              </v-radio-group>
            </v-card-text>

            <v-card-actions class="justify-end">
              <v-btn
                v-if="taskType == 'Add Task'"
                @click="updateTable"
                style="padding: 0 1.3rem"
                color="primary"
                ><v-icon small>add_circle</v-icon>Add</v-btn
              >
              <v-btn
                v-if="taskType == 'Edit Task'"
                @click="updateTable"
                style="padding: 0 1.3rem"
                color="primary"
                ><v-icon small>mdi-square-edit-outline</v-icon>Edit</v-btn
              >
              <v-btn color="error" @click="cancel">
                <v-icon small>mdi-cancel</v-icon>Cancel</v-btn
              >
            </v-card-actions>
          </v-card>
        </v-form>
      </v-overlay>
    </v-col>
  </v-row>
</template>

<script>
export default {
  name: "TaskCard",

  mounted() {
    // listen to Panel to reset form when new task is clicked
    this.$root.$on("reset-new-task-card", () => {
      this.$refs.form.resetValidation();
      this.title = "";
      this.description = "";
      this.formDeadline = this.formatDate(
        new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
          .toISOString()
          .substr(0, 10)
      );
      this.priority = "low";
      document.getElementById("newTask").style.display = "";
    });
    // listen to Table when entry attempted to be edited
    this.$root.$on(
      "edit-table-entry",
      (title, description, formDeadline, priority) => {
        this.title = title;
        this.description = description;
        this.formDeadline = formDeadline;
        this.priority = priority;
      }
    );
    // listen to Table when title is non distinct
    this.$root.$on("non-distinct-title", (replicaTitle) => {
      this.replicaTitle = replicaTitle;
    });
  },
  data() {
    return {
      // when title / description are empty
      rules: {
        titleReq: (value) => !!value || "Title is Required!",
        descReq: (value) => !!value || "Description is Required!",
        distinctReq: (value) => {
          this.$root.$emit("check-distinct-title", this.title);
          if (this.replicaTitle === value) return "Title must be distinct!";
          else return true;
        },
        //(this.replicaTitle != value) || "Title must be distinct!",
      },
      title: "",
      description: "",
      priority: "low",

      //formatted deadline
      formDeadline: this.formatDate(
        new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
          .toISOString()
          .substr(0, 10)
      ),

      // date picker
      date: new Date(Date.now() - new Date().getTimezoneOffset() * 60000)
        .toISOString()
        .substr(0, 10),
      // to track if the title is distinct
      replicaTitle: "",

      // boolean values for elements
      menu: false,
      modal: false,
      menu2: false,
      false: false,
    };
  },
  methods: {
    // close cards & reset form when cancel is pressed
    cancel() {
      if (this.taskType === "Add Task")
        document.getElementById("newTask").style.display = "none";
      else if (this.taskType === "Edit Task")
        document.getElementById("editTask").style.display = "none";
    },

    // send info to <Table> to update whatever necessary
    updateTable() {
      // if validation fails, do not submit
      if (!this.$refs.form.validate()) {
        return;
      }

      // otherwise send values to table to update table
      this.$root.$emit(
        "submit-new-change",
        this.taskType,
        this.title,
        this.description,
        this.formDeadline,
        this.priority
      );
    },

    // put into "MM/DD/YYYY" format
    formatDate(date) {
      if (!date) return null;

      const [year, month, day] = date.split("-");
      return `${month}/${day}/${year}`;
    },
    // to generate the calendar
    parseDate(date) {
      if (!date) return null;

      const [month, day, year] = date.split("/");
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    },
  },

  watch: {
    date(val) {
      this.formDeadline = this.formatDate(this.date);
    },
  },

  props: {
    taskType: String,
  },
};
</script>

