<template>
  <div class="hide-overflow" style="position: relative">
    <v-app-bar dark scroll-off-screen color="primary">
      <v-spacer></v-spacer>
      <v-toolbar-title>
        <v-icon>menu</v-icon>
        Frameworks
      </v-toolbar-title>

      <v-spacer></v-spacer>
      <v-btn @click="createNew" color="primary" dark>
        <v-icon>add_circle</v-icon>
        Add
      </v-btn>
    </v-app-bar>
  </div>
</template>

<script>
export default {
  methods: {
    // when adding a task let TaskCard know
    createNew() {
      this.$root.$emit("reset-new-task-card");
    },
  },
  data() {
    return {};
  },
};
</script>