import Vue from "vue";
import App from "./App";
import vuetify from "./vuetify";
import "material-design-icons-iconfont/dist/material-design-icons.css";

// import plugin
import VueToastr from "vue-toastr";
// use plugin
Vue.use(VueToastr, {
  defaultTimeout: 3000,
  defaultProgressBar: true,
  defaultPosition: "toast-bottom-right",
  defaultCloseOnHover: false,
  defaultClassNames: ["animated", "zoomInUp"]
});
Vue.config.productionTip = false;

/* eslint-disable no-new */
new Vue({
  vuetify,
  el: "#app",
  components: { App },
  template: "<App/>"
});
